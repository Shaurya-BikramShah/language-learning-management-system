/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package progressbar;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Shaurya
 */
public class Progressbar {
    public static void main(String[] args){
        ProgressbarFrame pf = new ProgressbarFrame();
        LoginFrame lf = new LoginFrame();
        pf.setVisible(true);
        
        for(int i = 1; i<=100; ++i){
            try {
                Thread.sleep(80);
                pf.progressBar.setValue(i);
                
                if(i%2==0){
                    pf.pleaseWait.setText("Please Wait..");
                }else{
                    pf.pleaseWait.setText("Please Wait...");
                }
                
                if(i==100){
                    pf.setVisible(false);
                    lf.setVisible(true);
                }
            } catch (InterruptedException ex) {
                Logger.getLogger(Progressbar.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
    }
}
